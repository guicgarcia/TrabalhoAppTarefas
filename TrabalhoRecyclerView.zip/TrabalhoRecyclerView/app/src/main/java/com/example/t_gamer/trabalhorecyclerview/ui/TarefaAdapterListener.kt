package com.example.t_gamer.trabalhorecyclerview.ui

interface TarefaAdapterListener {
}