package com.example.t_gamer.trabalhorecyclerview.ui

class TarefaAdapter {
}