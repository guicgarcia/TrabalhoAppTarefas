package com.example.t_gamer.trabalhorecyclerview.db.dao

interface TarefaDao {
}