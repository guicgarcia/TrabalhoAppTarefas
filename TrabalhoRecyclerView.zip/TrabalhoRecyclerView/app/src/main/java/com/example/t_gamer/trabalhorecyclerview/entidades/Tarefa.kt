package com.example.t_gamer.trabalhorecyclerview.entidades

class Tarefa {
}